package br.com.bank.service;

import java.util.List;

import br.com.bank.model.Cliente;

public interface ClienteService {
	
	public List<Cliente> list();
	
	public void save(Cliente cliente);
	
	public void deletar(Long idCliente);
	
	public Cliente findById(Long id);
	
	public void edit(Cliente cliente);
}
