package br.com.bank.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.bank.model.Client;
import br.com.bank.service.ClientServiceImpl;

@WebServlet("/clientServlet")
public class ClientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ClientServiceImpl service;
	
	public ClientServlet() {
		this.service = new ClientServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Response to client").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String name  = request.getParameter("name"); 
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		
		Client client = new Client();
		client.setName(name);
		client.setEmail(email);
		client.setPhone(phone);
		
		boolean emailExist = false;
		boolean phoneExist = false;
		
		List<Client> all = this.service.getAll();
		for (Client client2 : all) {
			if (client2.getEmail().equals(email)) {
				emailExist = true;
			}else if (client2.getPhone().equals(phone)) {
				phoneExist = true;
			}
		}
		
		if (emailExist) {
			
			RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
			request.setAttribute("error","Email" + email +"already exists.");
			rd.forward(request, response);
		
		} else if (phoneExist) {
			
			RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
			request.setAttribute("error","Phone" + phone +"already exists.");
			rd.forward(request, response);	
		
		}else if (emailExist == false && phoneExist == false) {
			if (name.equals("")) {
				
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				request.setAttribute("error","Name field is requisred");
				rd.forward(request, response);
		
			}else if (email.equals("")) {
				
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				request.setAttribute("error","Email field is requisred");
				rd.forward(request, response);
			
			}else if (email.equals("")) {
				
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				request.setAttribute("error","Phone field is requisred");
				rd.forward(request, response);
			
			}else {
				
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				request.setAttribute("success","Client" + name + "successfully registered.");
				rd.forward(request, response);
				this.service.save(client);
				
				
		}
				
			}
		
		
	}

}
