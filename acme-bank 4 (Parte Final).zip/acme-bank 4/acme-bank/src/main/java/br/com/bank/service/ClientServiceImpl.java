/**
 * 
 */
package br.com.bank.service;

import java.util.List;

import br.com.bank.dao.ClienteDaoImpl;
import br.com.bank.model.Cliente;

public class ClienteServiceImpl implements ClienteService{
	
	private ClienteDaoImpl dao;
	
	public ClienteServiceImpl() {
		this.dao = new ClienteDaoImpl();
	}
	
	@Override
	public List<Cliente> list() {
		return this.dao.list();
	}

	@Override
	public void save(Cliente cliente) {
		this.dao.save(cliente);
	}

	@Override
	public void deletar(Long idCliente) {
		this.dao.deletar(idCliente);
	}

	@Override
	public Cliente findById(Long id) {
		return this.dao.findById(id);
	}

	@Override
	public void edit(Cliente cliente) {
		this.dao.edit(cliente);
	}

}
